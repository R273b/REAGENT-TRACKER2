import React, { useState, useEffect } from "react";
import { supabase } from "./supabaseClient";

const ACTION_LABELS = {
  receive: "Received stock",
  edit_reagent: "Edited lot",
  delete_reagent: "Deleted lot",
  log_use: "Logged use",
  edit_log: "Edited usage log",
  delete_log: "Deleted usage log",
  preset_add: "Added preset",
  preset_delete: "Deleted preset",
  settings_change: "Changed settings",
  department_add: "Added department",
  department_remove: "Removed department",
  bulk_import: "Bulk imported",
};

export default function AuditTrail() {
  const [entries, setEntries] = useState(null);

  async function load() {
    const { data } = await supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(300);
    setEntries(data || []);
  }
  useEffect(() => { load(); }, []);

  if (entries === null) return <div style={{ padding: 40, textAlign: "center", color: "#8A9694" }}>Loading…</div>;

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 4 }}>Audit trail</h2>
      <div style={{ fontSize: 13, color: "#7B8E8A", marginBottom: 4 }}>Last 300 actions. Since this app uses shared admin/staff logins rather than individual accounts, "by" shows the role — actions that carry a name (received by, used by) include it in the details.</div>
      <div style={{ fontSize: 11.5, color: "#8A9694", marginBottom: 20 }}>Note: because both logins are shared and the anon database key is visible in the browser, this trail records what happened through the app's normal flow — it isn't a tamper-proof security log.</div>

      {entries.length === 0 ? (
        <div style={{ textAlign: "center", padding: "40px 20px", color: "#8A9694" }}>No actions logged yet.</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {entries.map((e) => (
            <div key={e.id} style={{ display: "flex", alignItems: "flex-start", gap: 12, background: "#fff", border: "1px solid #E1E8E5", borderRadius: 8, padding: "10px 14px", fontSize: 13 }}>
              <div style={{ width: 145, color: "#8A9694", fontFamily: "'IBM Plex Mono', monospace", fontSize: 11.5, flexShrink: 0 }}>{new Date(e.created_at).toLocaleString()}</div>
              <div style={{ width: 90, fontWeight: 700, flexShrink: 0 }}>{ACTION_LABELS[e.action] || e.action}</div>
              <div style={{ width: 70, color: "#516361", flexShrink: 0, textTransform: "capitalize" }}>{e.changed_by}</div>
              <div style={{ flex: 1, color: "#516361" }}>{e.entity ? <b>{e.entity}</b> : null}{e.entity && e.details ? " — " : ""}{e.details}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
