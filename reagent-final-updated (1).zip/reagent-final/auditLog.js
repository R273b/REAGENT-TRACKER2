import { supabase } from "./supabaseClient";

// Fire-and-forget audit log entry. Never throws — a logging failure
// shouldn't block the actual action that's being logged.
export async function logAction(role, action, entity, details) {
  try {
    await supabase.from("audit_log").insert({ action, entity: entity || null, changed_by: role, details: details || null });
  } catch {
    // ignore — logging is best-effort
  }
}
