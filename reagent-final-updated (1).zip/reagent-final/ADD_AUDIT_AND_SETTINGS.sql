-- Run this once in the SQL Editor of the SAME Supabase project used by
-- supabase_schema.sql (safe to re-run: everything is "if not exists" or
-- guarded so it won't duplicate data).

-- Audit trail: who did what, and when. "changed_by" is the logged-in role
-- ("admin"/"staff") since this app uses two shared logins rather than
-- individual accounts — for actions that already carry a real name
-- (received_by, used_by) that name is included in "details" too.
create table if not exists audit_log (
  id uuid primary key default gen_random_uuid(),
  action text not null,           -- e.g. "receive", "edit_reagent", "delete_reagent", "log_use", "edit_log", "delete_log", "preset_add", "preset_delete", "settings_change"
  entity text,                    -- e.g. reagent name
  changed_by text not null,       -- role: admin/staff
  details text,                   -- human-readable summary
  created_at timestamptz not null default now()
);
alter table audit_log enable row level security;
create policy "allow all audit_log" on audit_log for all using (true) with check (true);

-- Configurable department list (was hardcoded before) + configurable
-- "expiring soon" warning window (was a fixed 30 days before).
alter table app_config add column if not exists departments text[] not null default array['Chemistry','Hematology','Blood Bank'];
alter table app_config add column if not exists expiry_warning_days integer not null default 30;
