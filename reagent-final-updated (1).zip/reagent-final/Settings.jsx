import React, { useState } from "react";
import { Trash2, Plus, Save, Eye, EyeOff } from "lucide-react";
import { supabase } from "./supabaseClient";
import { logAction } from "./auditLog";

export default function Settings({ config, presets, reload }) {
  const [newPreset, setNewPreset] = useState({ name: "", department: config.departments?.[0] || "", unit: "mL" });
  const [creds, setCreds] = useState({
    lab_username: config.lab_username,
    lab_password: config.lab_password,
    admin_username: config.admin_username,
    admin_password: config.admin_password,
    low_stock_default_percent: config.low_stock_default_percent,
    expiry_warning_days: config.expiry_warning_days ?? 30,
  });
  const [showPasswords, setShowPasswords] = useState(false);
  const [departments, setDepartments] = useState(config.departments || []);
  const [newDept, setNewDept] = useState("");
  const [msg, setMsg] = useState("");

  async function addDepartment() {
    const name = newDept.trim();
    if (!name || departments.includes(name)) return;
    const updated = [...departments, name];
    setDepartments(updated);
    setNewDept("");
    await supabase.from("app_config").update({ departments: updated }).eq("id", 1);
    await logAction("admin", "department_add", name);
    reload();
  }
  async function removeDepartment(name) {
    if (!confirm(`Remove "${name}" from the department list? Existing reagents keep this department name, but you won't be able to pick it for new ones.`)) return;
    const updated = departments.filter((d) => d !== name);
    setDepartments(updated);
    await supabase.from("app_config").update({ departments: updated }).eq("id", 1);
    await logAction("admin", "department_remove", name);
    reload();
  }

  async function addPreset() {
    if (!newPreset.name) return;
    await supabase.from("reagent_presets").insert(newPreset);
    await logAction("admin", "preset_add", newPreset.name);
    setNewPreset({ name: "", department: departments[0] || "", unit: "mL" });
    reload();
  }

  async function deletePreset(id, name) {
    await supabase.from("reagent_presets").delete().eq("id", id);
    await logAction("admin", "preset_delete", name);
    reload();
  }

  async function saveCreds() {
    const { error } = await supabase.from("app_config").update(creds).eq("id", 1);
    setMsg(error ? "Could not save." : "Saved.");
    await logAction("admin", "settings_change", null, "Login credentials or defaults updated");
    reload();
    setTimeout(() => setMsg(""), 2500);
  }

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 4 }}>Settings</h2>
      <div style={{ fontSize: 13, color: "#7B8E8A", marginBottom: 24 }}>Only visible to your admin account.</div>

      <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 8, letterSpacing: 0.3 }}>DEPARTMENTS</div>
      <div style={{ background: "#fff", border: "1px solid #E1E8E5", borderRadius: 10, padding: 14, marginBottom: 30 }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: departments.length ? 10 : 0 }}>
          {departments.map((d) => (
            <span key={d} style={{ display: "flex", alignItems: "center", gap: 6, background: "#F0F3F2", borderRadius: 6, padding: "5px 10px", fontSize: 12.5, fontWeight: 600 }}>
              {d}
              <button onClick={() => removeDepartment(d)} style={{ background: "none", border: "none", color: "#C1432B", padding: 0, display: "flex" }}><Trash2 size={12} /></button>
            </span>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <input placeholder="New department name" value={newDept} onChange={(e) => setNewDept(e.target.value)} style={{ ...inputStyle, marginTop: 0, flex: 1 }} onKeyDown={(e) => e.key === "Enter" && addDepartment()} />
          <button onClick={addDepartment} style={{ background: "#0F7173", color: "#fff", border: "none", borderRadius: 7, padding: "0 14px", fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}><Plus size={14} /> Add</button>
        </div>
      </div>

      <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 8, letterSpacing: 0.3 }}>REAGENT PRESET LIST</div>
      <div style={{ fontSize: 12.5, color: "#7B8E8A", marginBottom: 12 }}>
        This is the list staff pick from at the "Details" step when receiving stock.
      </div>

      <div style={{ background: "#fff", border: "1px solid #E1E8E5", borderRadius: 10, padding: 14, marginBottom: 16 }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input
            placeholder="Reagent name"
            value={newPreset.name}
            onChange={(e) => setNewPreset((p) => ({ ...p, name: e.target.value }))}
            style={{ ...inputStyle, flex: 2, minWidth: 140, marginTop: 0 }}
          />
          <select
            value={newPreset.department}
            onChange={(e) => setNewPreset((p) => ({ ...p, department: e.target.value }))}
            style={{ ...inputStyle, flex: 1, minWidth: 120, marginTop: 0 }}
          >
            {departments.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
          <input
            placeholder="Unit"
            value={newPreset.unit}
            onChange={(e) => setNewPreset((p) => ({ ...p, unit: e.target.value }))}
            style={{ ...inputStyle, width: 80, marginTop: 0 }}
          />
          <button onClick={addPreset} style={{ background: "#0F7173", color: "#fff", border: "none", borderRadius: 7, padding: "0 14px", fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}>
            <Plus size={14} /> Add
          </button>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 30 }}>
        {presets.length === 0 && <div style={{ fontSize: 13, color: "#8A9694" }}>No presets yet — add your first reagent name above.</div>}
        {presets.map((p) => (
          <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 12, background: "#fff", border: "1px solid #E1E8E5", borderRadius: 8, padding: "9px 14px" }}>
            <div style={{ flex: 1, fontWeight: 600, fontSize: 13.5 }}>{p.name}</div>
            <div style={{ fontSize: 12.5, color: "#7B8E8A" }}>{p.department} · {p.unit}</div>
            <button onClick={() => deletePreset(p.id, p.name)} style={{ background: "none", border: "none", color: "#C1432B" }}><Trash2 size={15} /></button>
          </div>
        ))}
      </div>

      <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 8, letterSpacing: 0.3 }}>LOGIN & DEFAULTS</div>
      <div style={{ background: "#fff", border: "1px solid #E1E8E5", borderRadius: 10, padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ display: "flex", gap: 10 }}>
          <label style={{ ...labelStyle, flex: 1 }}>Staff username<input style={inputStyle} value={creds.lab_username} onChange={(e) => setCreds((c) => ({ ...c, lab_username: e.target.value }))} /></label>
          <label style={{ ...labelStyle, flex: 1 }}>Staff password<input type={showPasswords ? "text" : "password"} style={inputStyle} value={creds.lab_password} onChange={(e) => setCreds((c) => ({ ...c, lab_password: e.target.value }))} /></label>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <label style={{ ...labelStyle, flex: 1 }}>Your (admin) username<input style={inputStyle} value={creds.admin_username} onChange={(e) => setCreds((c) => ({ ...c, admin_username: e.target.value }))} /></label>
          <label style={{ ...labelStyle, flex: 1 }}>Your (admin) password<input type={showPasswords ? "text" : "password"} style={inputStyle} value={creds.admin_password} onChange={(e) => setCreds((c) => ({ ...c, admin_password: e.target.value }))} /></label>
        </div>
        <button type="button" onClick={() => setShowPasswords((v) => !v)} style={{ alignSelf: "flex-start", background: "none", border: "none", color: "#0F7173", fontSize: 12, fontWeight: 600, padding: 0, display: "flex", alignItems: "center", gap: 5 }}>
          {showPasswords ? <EyeOff size={13} /> : <Eye size={13} />} {showPasswords ? "Hide passwords" : "Show passwords"}
        </button>
        <label style={labelStyle}>Default low-stock alert (% of quantity received)
          <input type="number" style={inputStyle} value={creds.low_stock_default_percent} onChange={(e) => setCreds((c) => ({ ...c, low_stock_default_percent: Number(e.target.value) }))} />
        </label>
        <label style={labelStyle}>"Expiring soon" warning window (days before expiry)
          <input type="number" style={inputStyle} value={creds.expiry_warning_days} onChange={(e) => setCreds((c) => ({ ...c, expiry_warning_days: Number(e.target.value) }))} />
        </label>
        <button onClick={saveCreds} style={{ background: "#0F7173", color: "#fff", border: "none", borderRadius: 8, padding: "11px", fontWeight: 700, fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
          <Save size={14} /> Save settings
        </button>
        {msg && <div style={{ fontSize: 12.5, color: "#2F6B4F" }}>{msg}</div>}
      </div>

      <div style={{ fontSize: 11.5, color: "#8A9694", marginTop: 14 }}>
        Note: these credentials are stored as plain text in the database and the database's anon key is visible in the browser — fine for internal use, not for sensitive data. For real access control, this app would need to move to Supabase Auth with individual accounts, which is a bigger change than adjusting these settings.
      </div>
    </div>
  );
}

const inputStyle = { width: "100%", border: "1px solid #C7D1CE", borderRadius: 7, padding: "9px 11px", fontSize: 14, marginTop: 4, boxSizing: "border-box" };
const labelStyle = { fontSize: 12.5, fontWeight: 600, color: "#516361" };
